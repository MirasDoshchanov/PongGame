using UnityEngine;

public class MenuManager : MonoBehaviour
{
    public GameObject settingsMenu; 

    public void OpenSettings()
    {
        Debug.Log("Settings menu opened!");
        UnityEngine.SceneManagement.SceneManager.LoadScene("SettingsScene");
    }

    public void StartPlayerVsPlayer()
    {
        Debug.Log("Player vs Player selected!");
        UnityEngine.SceneManagement.SceneManager.LoadScene("PlayerVsPlayerScene");
    }

    public void StartPlayerVsAI()
    {
        Debug.Log("Player vs AI selected!");
        UnityEngine.SceneManagement.SceneManager.LoadScene("PlayerVsAIScene");
    }

    public void CloseSettings()
    {
        settingsMenu.SetActive(false); 
    }
}
