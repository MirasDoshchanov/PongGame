using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Ball : MonoBehaviour
{
    public float defaultSpeed = 10f;
    private float ballSpeed;
    public float speedIncrease = 0.2f;

    private int hitCounter;
    private Rigidbody2D rb;

    public Text opponentText; 
    public Text playerText;   

    public int maxScore = 11; 

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        
        
        ballSpeed = PlayerPrefs.GetFloat("BallSpeed", defaultSpeed);

        StartBall();
    }

    private void FixedUpdate()
    {
        
        rb.velocity = Vector2.ClampMagnitude(rb.velocity, ballSpeed + (speedIncrease * hitCounter));
    }

   
    private void StartBall()
    {
        rb.velocity = new Vector2(-1, 0) * (ballSpeed + speedIncrease * hitCounter);
    }

    
    private void RestartBall()
    {
        rb.velocity = Vector2.zero;
        transform.position = Vector2.zero;
        hitCounter = 0;
        Invoke("StartBall", 2f);
    }

    
    private void PlayerBounce(Transform obj)
    {
        hitCounter++;
        Vector2 ballPosition = transform.position;
        Vector2 playerPosition = obj.position;

        float xDirection = transform.position.x > 0 ? -1 : 1; 
        float yDirection = (ballPosition.y - playerPosition.y) / obj.GetComponent<Collider2D>().bounds.size.y; // Calculate angle

       
        yDirection = Mathf.Clamp(yDirection, -1f, 1f);

        
        rb.velocity = new Vector2(xDirection, yDirection) * (ballSpeed + (speedIncrease * hitCounter));
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        
        if (other.gameObject.name == "PaddleA" || other.gameObject.name == "PaddleB")
        {
            PlayerBounce(other.transform);
        }
    }

    
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (transform.position.x > 0) 
        {
            playerText.text = (int.Parse(playerText.text) + 1).ToString();
            CheckForWinner();
            RestartBall();
        }
        else if (transform.position.x < 0) 
        {
            opponentText.text = (int.Parse(opponentText.text) + 1).ToString();
            CheckForWinner(); 
            RestartBall();
        }
    }

    
    private void CheckForWinner()
    {
        int playerScore = int.Parse(playerText.text);
        int opponentScore = int.Parse(opponentText.text);

        if (playerScore >= maxScore || opponentScore >= maxScore)
        {
            EndGame(playerScore >= maxScore ? "Player A" : "Player B");
        }
    }

    public void EndGame(string winner)
    {
        PlayerPrefs.SetString("Winner", winner); 
        SceneManager.LoadScene("GameOverScene"); 
    }
}
