using UnityEngine;

public class vsAIController : MonoBehaviour
{
    public float speed = 10f;
    public bool isPlayerA = false;
    public GameObject ball;
    public float defaultPaddleSize = 1f;

    private Rigidbody2D rb;
    private Vector2 playerMovement;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        float paddleSize = PlayerPrefs.GetFloat("PaddleSize", defaultPaddleSize);

        transform.localScale = new Vector3(transform.localScale.x, paddleSize, transform.localScale.z);
    }

    void Update()
    {
        if (isPlayerA)
        {
            PaddleAController();
        }
        else
        {
            PaddleBController();
        }
    }

    private void PaddleBController()
    {
        if (ball.transform.position.y > transform.position.y + 0.5f)
        {
            playerMovement = new Vector2(0, 1);
        }
        else if (ball.transform.position.y < transform.position.y - 0.5f)
        {
            playerMovement = new Vector2(0, -1);
        }
        else
        {
            playerMovement = Vector2.zero;
        }
    }

    private void PaddleAController()
    {
        playerMovement = new Vector2(0, Input.GetAxis("Vertical"));
    }

    private void FixedUpdate()
    {
        rb.velocity = playerMovement * speed;
    }
}
