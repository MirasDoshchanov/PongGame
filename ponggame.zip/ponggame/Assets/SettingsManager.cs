using UnityEngine;
using UnityEngine.UI;

public class SettingsManager : MonoBehaviour
{
    public Slider ballSpeedSlider;
    public Slider paddleSizeSlider;

    public float ballSpeed;
    public float paddleSize;

void Start()
{
    ballSpeed = PlayerPrefs.GetFloat("BallSpeed", 10f);
    paddleSize = PlayerPrefs.GetFloat("PaddleSize", 1f);

    ballSpeedSlider.value = ballSpeed;
    paddleSizeSlider.value = paddleSize;
}


public void SaveSettings()
{
    Debug.Log("Saving Settings...");
    ballSpeed = ballSpeedSlider.value;
    paddleSize = paddleSizeSlider.value;

    PlayerPrefs.SetFloat("BallSpeed", ballSpeed);
    PlayerPrefs.SetFloat("PaddleSize", paddleSize);
    PlayerPrefs.Save();

    Debug.Log("Settings Saved: " + ballSpeed + ", " + paddleSize);
}


public void StartGame()
{
    SaveSettings();
    UnityEngine.SceneManagement.SceneManager.LoadScene("MainMenu");
}


}
